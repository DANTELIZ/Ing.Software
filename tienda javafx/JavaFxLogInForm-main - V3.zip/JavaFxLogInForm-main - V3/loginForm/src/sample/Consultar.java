package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Consultar {


    public Consultar() {

    }

    @FXML
    private Button Buscar, Regresar, Cancelar;
    @FXML
    private Label wrongProducto;
    @FXML
    private Label precioP;
    @FXML
    private Label categoriaP;
    @FXML
    private TextField Producto;
    @FXML
    private TextField Precio;
    @FXML
    private TextField Categoria;
    @FXML
    private ImageView imgjuego1, imgjuego2, imgjuego3, imgjuego4, imgjuego5;






    public void userCancelar(ActionEvent event) throws IOException {
        Main m = new Main();
        m.changeScene("afterLogin.fxml");

    }

    private void checkProducto() throws IOException {
        boolean datosProductoEncontrados = false;
        boolean productoEncontrado = false;



        if (Producto.getText().isEmpty()) {
            wrongProducto.setText("Debe ingresar el producto a buscar.");
        } else {

            BufferedReader reader = new BufferedReader(new FileReader("C:/Users/david/JavaFxLogInForm-main - V3/loginForm/src/sample/productos.txt"));
            String linea = reader.readLine();
            Main m = new Main();

            while (linea != null && datosProductoEncontrados == false) {
//En linea tenemos nombre y password juntos, separados por coma
//Usamos split() para que "corte" el String a partir de la coma
//Esto nos dará un array con dos elementos, el primer elemento contendrá el nombre y el segundo el password
                String[] datosProducto = linea.split(",");
//YA tenemos los datos separados, comprobamos si coinciden
                if (datosProducto[0].equals(Producto.getText().toString()))
                {
                    datosProductoEncontrados = true;         //Al pasar a true, el bucle while finalizará
                    Producto.setText(datosProducto[0]);
                    Precio.setText(datosProducto[1]);
                    Categoria.setText(datosProducto[2]);

                }
                else
                    linea = reader.readLine();

            }

            if (datosProductoEncontrados) {
                wrongProducto.setText("");
                Buscar.setVisible(false);
                Cancelar.setVisible(false);
                Regresar.setVisible(true);
                Categoria.setVisible(true);
                Precio.setVisible(true);
                precioP.setVisible(true);
                categoriaP.setVisible(true);
                if  (Producto.getText().toString().equals("FIFA"))
                    imgjuego1.setVisible(true);
                else
                    if  (Producto.getText().toString().equals("GTA5"))
                        imgjuego2.setVisible(true);
                   else
                       if  (Producto.getText().toString().equals("MARIO64"))
                            imgjuego3.setVisible(true);
                       else
                          if  (Producto.getText().toString().equals("PES"))
                           imgjuego4.setVisible(true);
                            else
                           imgjuego5.setVisible(true);

            } else {
                wrongProducto.setText("Producto no encontrado!");
            }


        }
    }

    public void userBuscar(ActionEvent event) throws IOException {

        checkProducto();

    }

    public void userRegresar(ActionEvent event) throws IOException {

        Main m = new Main();
        m.changeScene("Consulta.fxml");

    }

    public static boolean validarProducto(String Producto)  throws IOException {
        boolean Encontro = false;

        BufferedReader reader = new BufferedReader(new FileReader("C:/Users/david/JavaFxLogInForm-main - V3/loginForm/src/sample/productos.txt"));
        String linea = reader.readLine();

        while (linea != null && Encontro == false) {
            String[] datosProducto = linea.split(",");
            if (datosProducto[0].equals(Producto.toString()))
                Encontro = true;
            else
                linea = reader.readLine();

        }

        return Encontro;


    }


}