package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.Writer;

import java.io.IOException;
public class Registro {

    public Registro() {

    }

    @FXML
    private Button Registrar;
    @FXML
    private Label wrongregistrar;
    @FXML
    private TextField usuario;
    @FXML
    private TextField email;
    @FXML
    private PasswordField contra;


    public void userRegistro(ActionEvent event) throws IOException {
        guardarRegistro();

    }

    private void guardarRegistro() throws IOException {


        Writer output;
        output = new BufferedWriter(new FileWriter("C:/Users/david/JavaFxLogInForm-main - V3/loginForm/src/sample/texto.txt", true));
        ((BufferedWriter) output).newLine();
        output.append(usuario.getText().toString()+","+contra.getText().toString());
        output.close();
        Main m = new Main();
        m.changeScene("sample.fxml");




    }

}
