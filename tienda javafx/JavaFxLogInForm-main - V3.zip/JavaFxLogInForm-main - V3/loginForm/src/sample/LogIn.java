package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
public class LogIn {

    public LogIn() {

    }

    @FXML
    private Button button;
    @FXML
    private Label wrongLogIn;
    @FXML
    public TextField username;
    @FXML
    public PasswordField password;



    public void userLogIn(ActionEvent event) throws IOException {
        boolean rta = checkLogin();

    }

    public boolean checkLogin() throws IOException {
        boolean datosLoginEncontrados = false;
        boolean usuarioEncontrado = false;
        boolean passEncontrado = false;

        if (username.getText().isEmpty() && password.getText().isEmpty()) {
            wrongLogIn.setText("Debe ingresar sus datos.");
        } else {

            BufferedReader reader = new BufferedReader(new FileReader("C:/Users/david/JavaFxLogInForm-main - V3/loginForm/src/sample/texto.txt"));
            String linea = reader.readLine();
            Main m = new Main();

            while (linea != null && datosLoginEncontrados == false) {
//En linea tenemos nombre y password juntos, separados por coma
//Usamos split() para que "corte" el String a partir de la coma
//Esto nos dará un array con dos elementos, el primer elemento contendrá el nombre y el segundo el password
                String[] datosLogin = linea.split(",");
//YA tenemos los datos separados, comprobamos si coinciden
                if (datosLogin[0].equals(username.getText().toString()) && datosLogin[1].equals(password.getText().toString()))
                    datosLoginEncontrados = true;//Al pasar a true, el bucle while finalizará
                else
                    linea = reader.readLine();

            }

            if (datosLoginEncontrados) {
                m.changeScene("afterLogin.fxml");
            } else {
                wrongLogIn.setText("Usuario o contraseña incorrectos!");
            }

                    }
        return datosLoginEncontrados;
    }

    public void userRegister(ActionEvent event) throws IOException {
        Main m = new Main();

        m.changeScene("Register.fxml");

    }

    public static boolean validarUsuario(String usuario, String contrasena)  throws IOException {
        boolean Encontro = false;

            BufferedReader reader = new BufferedReader(new FileReader("C:/Users/david/JavaFxLogInForm-main - V3/loginForm/src/sample/texto.txt"));
            String linea = reader.readLine();

            while (linea != null && Encontro == false) {
               String[] datosLogin = linea.split(",");
                if (datosLogin[0].equals(usuario.toString()) && datosLogin[1].equals(contrasena.toString()))
                    Encontro = true;
                else
                    linea = reader.readLine();

            }

        return Encontro;


    }

}