package test;

import org.junit.Test;
import sample.Consultar;
import sample.LogIn;

import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class TestTienda {

    private String usuario;
    private String contrasena;
    private String producto;

    @Test
    public void testLogIn() throws IOException {

        LogIn loginok = new LogIn();

        usuario="DANTELIZ";
        contrasena="david2002";

        assertTrue(LogIn.validarUsuario(usuario,contrasena));

        LogIn loginmal = new LogIn();

        usuario="DANTELIZ";
        contrasena="nueva";

        assertEquals(false, LogIn.validarUsuario(usuario, contrasena));

    }


    @Test
    public void testProducto() throws IOException {

        Consultar consultarok = new Consultar();

        producto="FIFA";

        assertTrue(Consultar.validarProducto(producto));

        Consultar consultarmal = new Consultar();

        producto="SONIC";

        assertEquals(false, Consultar.validarProducto(producto));

    }

}
